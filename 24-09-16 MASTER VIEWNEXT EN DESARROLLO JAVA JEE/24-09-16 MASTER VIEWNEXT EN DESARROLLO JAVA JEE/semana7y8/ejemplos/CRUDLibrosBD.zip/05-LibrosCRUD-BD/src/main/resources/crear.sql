CREATE TABLE `31octubre`.`libros` (
  `isbn` INT NOT NULL,
  `titulo` VARCHAR(45) NULL,
  `tematica` VARCHAR(45) NULL,
  PRIMARY KEY (`isbn`));
