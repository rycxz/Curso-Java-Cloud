package com.curso.service;

import java.util.List;

import com.curso.modelo.Ejemplar;

public interface EjemplarService {
	List<Ejemplar> nuevoEjemplar(Ejemplar ejemplar);
}
