INSERT INTO `Categorias` (`nombre`, `descripcion`) VALUES ('programacion','libros de programacion');
INSERT INTO `Categorias` (`nombre`, `descripcion`) VALUES ('web','libros web');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('1AB', 'Java', 'pepito', '3','programacion');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('2AC', 'Java Web', 'pepito', '3','programacion');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('3BC', 'html', 'gema',  '2','web');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('4BD', 'html5', 'andres', '2','web');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('5BD', 'C', 'maria', '5','programacion');
INSERT INTO `Libros` (`isbn`, `titulo`, `autor`,  `precio`,`categorias_nombre`) VALUES ('6FG', 'PHP', null, '4','programacion');