
DROP TABLE   if exists Libros;
DROP TABLE   if exists Categorias;