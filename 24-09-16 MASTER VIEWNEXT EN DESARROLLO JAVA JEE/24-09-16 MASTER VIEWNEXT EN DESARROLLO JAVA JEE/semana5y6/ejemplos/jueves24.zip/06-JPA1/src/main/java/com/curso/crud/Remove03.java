package com.curso.crud;

import com.curso.model.Libro;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Remove03 {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("biblioteca");//el nombre de la unidad de persistencia del persistence.xml
		EntityManager em = emf.createEntityManager();
		
		Libro libro = em.find(Libro.class, "1B");   // COMPROBACIONES para vosotros
		
		em.getTransaction().begin();
		em.remove(libro);		
		em.getTransaction().commit();
		

	}

}
