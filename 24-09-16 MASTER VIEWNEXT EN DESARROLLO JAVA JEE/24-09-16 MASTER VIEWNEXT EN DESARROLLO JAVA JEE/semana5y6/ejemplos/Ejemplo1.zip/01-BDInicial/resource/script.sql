CREATE DATABASE bdcurso;
USE bdcurso;
CREATE TABLE `bdcurso`.`personas` (
  `nombre` VARCHAR(10) NULL,
  `apellido` VARCHAR(45) NULL,
  `edad` INT NULL);
  
  